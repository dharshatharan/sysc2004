
public class __SHELL7 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("/Users/Dharshan/Desktop/Fall 2019/SYSC 2004/Assignment 4/zuul");
final Game game1 = (Game)__bluej_runtime_scope.get("game1");


game1.play();

}}
